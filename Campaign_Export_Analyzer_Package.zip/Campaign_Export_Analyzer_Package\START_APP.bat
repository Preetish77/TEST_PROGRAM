@echo off
title Campaign Export Analyzer
cd /d "%~dp0"

echo.
echo  Campaign Export Analyzer - Local App
echo  ===================================
echo.
echo  Folder: %CD%
echo  URL:    http://127.0.0.1:5000
echo.

echo %CD% | findstr /i "\.zip AppData\\Local\\Temp" >nul
if %errorlevel%==0 (
    echo  ERROR: You are running from INSIDE the zip file.
    echo.
    echo  FIX:
    echo  1. Right-click Campaign_Export_Analyzer_Package.zip
    echo  2. Choose "Extract All..."
    echo  3. Open the extracted Campaign_Export_Analyzer_Package folder
    echo  4. Double-click START_APP.bat from THAT folder
    echo.
    pause
    exit /b 1
)

echo  IMPORTANT: Keep this window OPEN while using the app.
echo.

set MISSING=0
if not exist "requirements.txt" (echo  MISSING: requirements.txt & set MISSING=1)
if not exist "app.py" (echo  MISSING: app.py & set MISSING=1)
if not exist "analyzer.py" (echo  MISSING: analyzer.py & set MISSING=1)
if not exist "ko_parser.py" (echo  MISSING: ko_parser.py & set MISSING=1)
if not exist "templates\index.html" (echo  MISSING: templates\index.html & set MISSING=1)

if %MISSING%==1 (
    echo.
    echo  ERROR: Incomplete project folder.
    echo  You need the FULL zip — not just START_APP.bat.
    echo  Ask your teammate to run PACK_FOR_TEAMMATE.bat and resend the zip.
    echo.
    echo  Also: Right-click zip -^> Extract All (do not run from inside the zip).
    echo.
    pause
    exit /b 1
)

REM Stop any old server still running on port 5000
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":5000" ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
)

where py >nul 2>&1
if errorlevel 1 (
    echo  ERROR: Python is not installed.
    echo  Install from https://www.python.org/downloads/
    echo  Check "Add Python to PATH" during install.
    echo.
    pause
    exit /b 1
)

echo  Installing dependencies (first time may take 1-2 min)...
py -3 -m pip install -r requirements.txt -q --no-warn-script-location
if errorlevel 1 (
    echo  Failed to install dependencies.
    pause
    exit /b 1
)

echo  Starting server... browser will open in a few seconds.
echo.
py -3 app.py
echo.
echo  Server stopped.
pause
