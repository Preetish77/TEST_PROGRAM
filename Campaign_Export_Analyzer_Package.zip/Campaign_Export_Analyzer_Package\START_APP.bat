@echo off
setlocal EnableDelayedExpansion
title Campaign Export Analyzer
cd /d "%~dp0"

echo.
echo  Campaign Export Analyzer - Local App
echo  ===================================
echo.
echo  Folder: %CD%
echo  URL:    http://127.0.0.1:5000
echo.
echo  Do NOT double-click app.py — use THIS file (START_APP.bat).
echo.

echo %CD% | findstr /i "\.zip AppData\\Local\\Temp" >nul
if !errorlevel!==0 (
    call :fail "You are running from INSIDE the zip or a temp folder." ^
        "Right-click the zip -^> Extract All -^> open Campaign_Export_Analyzer_Package -^> double-click START_APP.bat"
)

echo  IMPORTANT: Keep this window OPEN while using the app.
echo.

set MISSING=0
if not exist "requirements.txt" (echo  MISSING: requirements.txt & set MISSING=1)
if not exist "app.py" (echo  MISSING: app.py & set MISSING=1)
if not exist "analyzer.py" (echo  MISSING: analyzer.py & set MISSING=1)
if not exist "ko_parser.py" (echo  MISSING: ko_parser.py & set MISSING=1)
if not exist "templates\index.html" (echo  MISSING: templates\index.html & set MISSING=1)

if !MISSING!==1 (
    call :fail "Incomplete project folder." ^
        "Ask your teammate to resend Campaign_Export_Analyzer_Package.zip and Extract All."
)

REM Stop any old server still running on port 5000
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":5000" ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
)

set PYTHON_CMD=
where py >nul 2>&1
if !errorlevel!==0 (
    py -3 -c "import sys" >nul 2>&1
    if !errorlevel!==0 set PYTHON_CMD=py -3
)
if not defined PYTHON_CMD (
    where python >nul 2>&1
    if !errorlevel!==0 (
        python -c "import sys" >nul 2>&1
        if !errorlevel!==0 set PYTHON_CMD=python
    )
)
if not defined PYTHON_CMD (
    call :fail "Python 3 is not installed or not on PATH." ^
        "1. Go to https://www.python.org/downloads/" ^
        "2. Install Python 3" ^
        "3. CHECK the box: Add Python to PATH" ^
        "4. Close this window, open a NEW folder window, double-click START_APP.bat again" ^
        "Tip: run CHECK_SETUP.bat first to verify Python."
)

echo  Using: !PYTHON_CMD!
echo.
echo  Installing dependencies (first time may take 1-2 min)...
!PYTHON_CMD! -m pip install -r requirements.txt -q --no-warn-script-location
if !errorlevel! neq 0 (
    call :fail "Failed to install dependencies." ^
        "Try running CHECK_SETUP.bat and send startup_log.txt to your teammate."
)

echo  Starting server... browser should open in a few seconds.
echo  If the browser does not open, go to: http://127.0.0.1:5000
echo.
!PYTHON_CMD! app.py
if !errorlevel! neq 0 (
    echo.
    echo  ERROR: The app stopped unexpectedly (exit code !errorlevel!).
    echo  See startup_log.txt in this folder, or run CHECK_SETUP.bat.
    echo.
)
echo.
echo  Server stopped.
pause
exit /b 0

:fail
echo.
echo  ERROR: %~1
echo.
shift
:fail_more
if "%~1"=="" goto fail_done
echo  %~1
shift
goto fail_more
:fail_done
echo.
echo  A copy of this message is saved to startup_log.txt
(
    echo Campaign Export Analyzer - startup failed
    echo Folder: %CD%
    echo Date: %DATE% %TIME%
    echo.
    echo ERROR: %~1
) > startup_log.txt
pause
exit /b 1
