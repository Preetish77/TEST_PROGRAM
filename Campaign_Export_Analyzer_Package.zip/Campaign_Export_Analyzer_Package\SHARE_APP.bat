@echo off
title Campaign Export Analyzer - Share Mode
cd /d "%~dp0"

echo.
echo  Campaign Export Analyzer - SHARE MODE
echo  -------------------------------------
echo  Others on your network can connect.
echo.

where py >nul 2>&1
if errorlevel 1 (
    echo  ERROR: Python is not installed.
    pause
    exit /b 1
)

py -3 -m pip install -r requirements.txt -q
py -3 app.py --share
pause
