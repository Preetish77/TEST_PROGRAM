import argparse
import csv
import io
import socket
import sys
import threading
import webbrowser
from datetime import datetime
from pathlib import Path

from flask import Flask, jsonify, render_template, request

from analyzer import analyze_file, get_export_metadata, read_csv_rows


def create_app():
    if getattr(sys, "frozen", False):
        base = Path(sys._MEIPASS)
        return Flask(__name__, template_folder=str(base / "templates"))
    return Flask(__name__, template_folder=str(Path(__file__).parent / "templates"))


app = create_app()
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50 MB
app.config["TEMPLATES_AUTO_RELOAD"] = True


def local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "127.0.0.1"


def _parse_date(value):
    text = (value or "").strip()
    if not text:
        return None
    return datetime.strptime(text, "%Y-%m-%d").date()


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/export-meta")
def export_meta():
    export_file = request.files.get("export_file")
    if not export_file or not export_file.filename:
        return jsonify({"error": "Upload the campaign export file first."}), 400

    try:
        _, rows = read_csv_rows(io.BytesIO(export_file.read()))
        meta = get_export_metadata(rows)
        delivered = sum(
            1 for r in rows if (r.get("status") or "").strip().lower() == "delivered"
        )
        return jsonify(
            {
                "filename": export_file.filename,
                "campaign_names": meta["campaign_names"],
                "timestamp_min": meta["timestamp_min"],
                "timestamp_max": meta["timestamp_max"],
                "row_count": len(rows),
                "delivered_count": delivered,
            }
        )
    except Exception as exc:
        return jsonify({"error": str(exc)}), 400


@app.post("/analyze")
def analyze():
    export_file = request.files.get("export_file")
    ko_file = request.files.get("ko_file")
    campaign_name = (request.form.get("campaign_name") or "").strip()

    if not export_file or not export_file.filename:
        return jsonify({"error": "Campaign export file is required."}), 400
    if not ko_file or not ko_file.filename:
        return jsonify({"error": "KO Creative Details file is required."}), 400
    if not campaign_name:
        return jsonify({"error": "Select a campaign name."}), 400

    try:
        timestamp_from = _parse_date(request.form.get("timestamp_from"))
        timestamp_to = _parse_date(request.form.get("timestamp_to"))
        report = analyze_file(
            io.BytesIO(export_file.read()),
            export_file.filename,
            io.BytesIO(ko_file.read()),
            ko_file.filename,
            campaign_name=campaign_name,
            timestamp_from=timestamp_from,
            timestamp_to=timestamp_to,
            require_ko=True,
        )
        return jsonify(report)
    except csv.Error as exc:
        return jsonify({"error": f"Could not parse CSV: {exc}"}), 400
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


def open_browser(url):
    webbrowser.open(url)


def main():
    parser = argparse.ArgumentParser(description="Campaign Export Analyzer")
    parser.add_argument("--share", action="store_true", help="Allow others on your network to connect")
    parser.add_argument("--port", type=int, default=5000, help="Port number (default: 5000)")
    parser.add_argument("--no-browser", action="store_true", help="Do not open browser automatically")
    args = parser.parse_args()

    host = "0.0.0.0" if args.share else "127.0.0.1"
    local_url = f"http://127.0.0.1:{args.port}"

    print()
    print("=" * 50)
    print("  Campaign Export Analyzer (local)")
    print("=" * 50)
    print()
    print(f"  Your browser:  {local_url}")

    if args.share:
        ip = local_ip()
        print(f"  Share this:    http://{ip}:{args.port}")
        print()
        print("  Others on the same Wi-Fi/network can use the link above.")
        print("  Keep this window open while they use the app.")
    else:
        print()
        print("  Local only — not hosted on Streamlit.")

    print()
    print("  Press Ctrl+C to stop.")
    print("=" * 50)
    print()

    if not args.no_browser:
        threading.Timer(1.2, open_browser, args=[local_url]).start()

    app.run(debug=False, host=host, port=args.port, use_reloader=False)


if __name__ == "__main__":
    main()
